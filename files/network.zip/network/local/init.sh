# grant access to the network file
cd ..
chmod -R +x ./local
cd ./local

printf "\033[1;93mPlease execute ./start.sh command now\033[0m\n"

